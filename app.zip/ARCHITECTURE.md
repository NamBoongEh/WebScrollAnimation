```mermaid
%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#3b82f6', 'primaryTextColor': '#fff', 'primaryBorderColor': '#2563eb', 'lineColor': '#6b7280', 'secondaryColor': '#f5f7fa', 'tertiaryColor': '#e5e7eb'}}}%%

graph TB
    subgraph HTML["📄 index.html"]
        direction TB
        CardStack["div.card-stack"]
        Card1["section#card-1<br/>충돌감지 플립카드"]
        Card2["section#card-2<br/>비디오 그리드"]
        Card3["section#card-3<br/>CSS 나선계단"]
        Card4["section#card-4<br/>빈 카드"]
        Card5["section#card-5<br/>Three.js 나선계단"]
        Card6["section#card-6<br/>빈 카드"]
        Indicator["nav.indicator"]
        Popups["Popups<br/>popup-overlay, video-popup"]
        MuteBtn["button.mute-btn"]
        
        CardStack --> Card1
        CardStack --> Card2
        CardStack --> Card3
        CardStack --> Card4
        CardStack --> Card5
        CardStack --> Card6
    end

    subgraph CSS["🎨 styles.css"]
        direction TB
        BaseReset["Base Reset & CSS Variables"]
        CardStyles["Card Stack & States<br/>active, prev-1, prev-2, fullscreen"]
        Card1CSS["Card1: Scatter Items<br/>3D flip animation"]
        Card2CSS["Card2: Video Grid<br/>masonry layout"]
        Card5CSS["Card5: Three.js Container"]
        Animations["Animations<br/>exitDown, enterUp, etc."]
        Responsive["Mobile Responsive"]
        
        BaseReset --> CardStyles
        CardStyles --> Card1CSS
        CardStyles --> Card2CSS
        CardStyles --> Card5CSS
        CardStyles --> Animations
        Animations --> Responsive
    end

    subgraph JS["⚡ app.js"]
        direction TB
        
        subgraph Utils["🔧 Utils"]
            $["$ / $$ selectors"]
            lerp["lerp()"]
            clamp["clamp()"]
        end
        
        subgraph AppModule["🎮 App (Main Controller)"]
            AppInit["init()"]
            Navigation["navigateTo()"]
            Fullscreen["enterFullscreen()<br/>exitFullscreen()"]
            WheelHandler["handleWheel()"]
            Animate["animate() - parallax"]
        end
        
        subgraph Card1Module["🃏 Card1"]
            C1Init["init()"]
            C1Position["updatePosition()"]
            C1Collision["checkCollision()"]
            C1Animate["animate() - lerp movement"]
        end
        
        subgraph Card2Module["🎬 Card2"]
            C2Init["init()"]
            C2PauseAll["pauseAll()"]
            C2Resume["resume()"]
        end
        
        subgraph Card5Module["🏛️ Card5 (Three.js)"]
            C5Init["initThree()"]
            C5Pillar["createPillar()"]
            C5Stairs["createStairs()<br/>반시계 방향"]
            C5Frame["createFrame()"]
            C5Camera["updateCamera()<br/>1인칭 시점"]
            C5Animate["animate()"]
        end
        
        subgraph PopupModule["💬 Popup / VideoPopup"]
            PopupOpen["open()"]
            PopupClose["close()"]
        end
        
        Utils --> AppModule
        AppModule --> Card1Module
        AppModule --> Card2Module
        AppModule --> Card5Module
        AppModule --> PopupModule
    end

    HTML --> CSS
    HTML --> JS
    
    style HTML fill:#e0f2fe,stroke:#0284c7
    style CSS fill:#fef3c7,stroke:#d97706
    style JS fill:#dcfce7,stroke:#16a34a
```

---

# 📁 프로젝트 구조

```
project/
├── index.html          # 메인 HTML (모든 카드 구조)
├── styles.css          # 통합 스타일시트
├── app.js              # 통합 자바스크립트
├── Image/
│   └── human.jpg       # Card1 아바타 이미지
└── Video/
    ├── vid1.mp4
    ├── vid2.mp4
    ├── vid3.mp4
    ├── vid4.mp4
    ├── vid5.mp4
    └── vid6.mp4
```

---

# 🔄 데이터 흐름

```
┌─────────────────────────────────────────────────────────────────┐
│                         User Input                               │
│  (click, scroll, touch, keyboard)                               │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                      App Controller                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Navigation   │  │ Fullscreen   │  │ Parallax     │          │
│  │ (wheel/key)  │  │ (click)      │  │ (mouse move) │          │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘          │
└─────────┼─────────────────┼─────────────────┼───────────────────┘
          │                 │                 │
          ▼                 ▼                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Card Modules                                │
│                                                                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │   Card1     │  │   Card2     │  │   Card5     │             │
│  │  - 충돌감지  │  │  - 비디오   │  │  - Three.js │             │
│  │  - 플립     │  │  - 재생/정지│  │  - 계단상승  │             │
│  │  - 아바타   │  │  - 음소거   │  │  - 액자클릭  │             │
│  └─────────────┘  └─────────────┘  └─────────────┘             │
│         │                │                │                      │
└─────────┼────────────────┼────────────────┼─────────────────────┘
          │                │                │
          ▼                ▼                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Popup System                                │
│  ┌──────────────────┐  ┌──────────────────┐                     │
│  │  General Popup   │  │  Video Popup     │                     │
│  │  (Card1 버튼)    │  │  (Card5 액자)    │                     │
│  └──────────────────┘  └──────────────────┘                     │
└─────────────────────────────────────────────────────────────────┘
```

---

# 🎯 주요 기능별 흐름

## 1. Card1 충돌 감지 플립

```
사용자 클릭 (fullscreen 상태)
    │
    ▼
target 좌표 설정
    │
    ▼
animate() 루프에서 lerp로 이동
    │
    ▼
checkCollision() 매 프레임 실행
    │
    ▼
getBoundingClientRect() 비교
    │
    ▼
충돌 시 .flipped 클래스 추가
    │
    ▼
CSS transform: rotateY(180deg) 실행
```

## 2. Card5 나선 계단 (반시계 방향)

```
휠/터치 입력
    │
    ▼
targetScroll 업데이트
    │
    ▼
animate()에서 lerp 보간
    │
    ▼
updateCamera() 호출
    │
    ├─── 현재 층 계산: stairIdx = scroll/maxScroll * TOTAL_STAIRS
    │
    ├─── 카메라 위치: angle = stairIdx * ANGLE_PER_STAIR (양수 = 반시계)
    │                 position = (cos(angle) * R, height, sin(angle) * R)
    │
    └─── 시선 방향: 2.5계단 앞 바라봄 (자연스러운 상승감)
    │
    ▼
renderer.render(scene, camera)
```

---

# 📝 수정사항 요약

| 항목 | 변경 전 | 변경 후 |
|------|---------|---------|
| Card5 계단 방향 | 시계 방향 (-24) | **반시계 방향 (+24)** |
| 스크롤 threshold | 500 | **250** (더 빠른 반응) |
| 스크롤 감도 | deltaY * 0.5 | **deltaY * 0.8** (더 민감) |
| lerp 속도 | 0.08 | **0.12** (더 부드러운 보간) |
| 카드 전환 시간 | 1s | **0.8s** (더 빠른 전환) |

---

# 🎬 카드 전환 애니메이션

## 아래로 스크롤 시 (다음 카드로)
```
[현재 카드]                    [다음 카드]
scale: 1.0                     scale: 1.15
z: 0                           z: 150px (앞쪽)
Y: 0                           Y: 60% (화면 아래)
    │                              │
    ▼ 스크롤 진행 (부드러운 lerp)    ▼
    │                              │
scale: 0.5                     scale: 1.0
z: -100px (뒤로)               z: 0
Y: 60%                         Y: 0 (제자리)
(뒤로 밀려남)                   (아래에서 부드럽게 올라옴)
```

## requestAnimationFrame 이중 호출로 부드러운 전환
```javascript
// 1. transition: none으로 초기 위치 설정
// 2. 두 프레임 대기 후 transition 적용하여 애니메이션 시작
requestAnimationFrame(() => {
  requestAnimationFrame(() => {
    newCard.style.transition = transition;
    newCard.style.transform = '최종 위치';
  });
});
```
