// Card 1 내부 애니메이션 - 충돌 감지 및 카드 플립
(function() {
  const card1 = document.getElementById('card-1');
  const humanImage = document.getElementById('human-image');
  const gridContainer = document.getElementById('grid-container-1');
  const popupOverlay = document.getElementById('popup-overlay');
  const popupClose = document.getElementById('popup-close');
  
  if (!card1 || !humanImage || !gridContainer) return;
  
  // Human 위치 (비율 0~1)
  let ratioX = 0.50;
  let ratioY = 0.08;
  let wasFullscreen = false;
  let isTransitioning = false;
  
  // 애니메이션 변수
  let targetX = ratioX;
  let targetY = ratioY;
  let currentX = ratioX;
  let currentY = ratioY;
  let isMoving = false;
  let animationId = null;
  
  // human 위치 업데이트
  function updatePosition() {
    humanImage.style.left = (currentX * 100) + '%';
    humanImage.style.top = (currentY * 100) + '%';
    humanImage.style.transform = 'translate(-50%, -50%)';
  }
  
  // fullscreen 상태 감지
  function watchFullscreen() {
    const isFullscreen = card1.classList.contains('fullscreen');
    if (wasFullscreen !== isFullscreen) {
      isTransitioning = true;
      setTimeout(() => { isTransitioning = false; }, 650);
      wasFullscreen = isFullscreen;
    }
    requestAnimationFrame(watchFullscreen);
  }
  
  // 클릭 이벤트
  card1.addEventListener('click', (e) => {
    if (!card1.classList.contains('fullscreen')) return;
    if (isTransitioning) return;
    if (e.target.closest('.close-button')) return;
    if (e.target.closest('.grid-button')) return;
    
    const rect = card1.getBoundingClientRect();
    targetX = (e.clientX - rect.left) / rect.width;
    targetY = (e.clientY - rect.top) / rect.height;
    
    // 경계 제한
    targetX = Math.max(0.05, Math.min(0.95, targetX));
    targetY = Math.max(0.05, Math.min(0.95, targetY));
    
    if (!isMoving) {
      isMoving = true;
      animate();
    }
  });
  
  // easeOut (처음 빠르고 점점 느려짐)
  function easeOut(t) {
    return 1 - Math.pow(1 - t, 3);
  }
  
  // 애니메이션 루프 - 부드러운 lerp 방식
  function animate() {
    if (isTransitioning) {
      isMoving = false;
      return;
    }
    
    // lerp로 부드럽게 이동
    const speed = 0.08;
    const dx = targetX - currentX;
    const dy = targetY - currentY;
    
    currentX += dx * speed;
    currentY += dy * speed;
    
    updatePosition();
    checkCollision();
    
    // 충분히 가까우면 멈춤
    if (Math.abs(dx) < 0.001 && Math.abs(dy) < 0.001) {
      currentX = targetX;
      currentY = targetY;
      updatePosition();
      isMoving = false;
      return;
    }
    
    animationId = requestAnimationFrame(animate);
  }
  
  // 충돌 감지 - human이 카드에 닿는 순간 뒤집기
  function checkCollision() {
    if (!card1.classList.contains('fullscreen')) return;
    if (isTransitioning) return;
    
    const hRect = humanImage.getBoundingClientRect();
    const items = gridContainer.querySelectorAll('.scatter-item');
    
    items.forEach(item => {
      if (item.classList.contains('flipped')) return;
      
      // card-inner의 실제 렌더링 영역을 사용
      const cardInner = item.querySelector('.card-inner');
      if (!cardInner) return;
      
      const iRect = cardInner.getBoundingClientRect();
      
      // 유효한 크기인지 확인
      if (iRect.width === 0 || iRect.height === 0) return;
      
      // 사각형 충돌 감지
      const hit = !(hRect.right < iRect.left || 
                    hRect.left > iRect.right || 
                    hRect.bottom < iRect.top || 
                    hRect.top > iRect.bottom);
      
      if (hit) {
        item.classList.add('flipped');
        // 플립 효과음이나 추가 효과를 여기에 넣을 수 있음
      }
    });
  }
  
  // 버튼 클릭 → 팝업
  gridContainer.addEventListener('click', (e) => {
    const btn = e.target.closest('.grid-button');
    if (btn) {
      e.stopPropagation();
      const item = btn.closest('.scatter-item');
      const idx = item ? item.dataset.index : 0;
      openPopup(idx);
    }
  });
  
  function openPopup(idx) {
    const content = document.getElementById('popup-content');
    if (content) {
      content.querySelector('h2').textContent = '아이템 ' + (parseInt(idx) + 1);
      content.querySelector('p').textContent = '이것은 ' + (parseInt(idx) + 1) + '번 아이템의 상세 내용입니다.';
    }
    if (popupOverlay) popupOverlay.classList.add('active');
  }
  
  if (popupClose) {
    popupClose.addEventListener('click', () => {
      popupOverlay.classList.remove('active');
    });
  }
  
  if (popupOverlay) {
    popupOverlay.addEventListener('click', (e) => {
      if (e.target === popupOverlay) {
        popupOverlay.classList.remove('active');
      }
    });
  }
  
  // 카드1 리셋 함수
  window.resetCard1Grid = function() {
    const items = gridContainer.querySelectorAll('.scatter-item');
    items.forEach(item => {
      item.classList.remove('flipped');
    });
    // human 위치 초기화
    targetX = 0.50;
    targetY = 0.08;
    currentX = 0.50;
    currentY = 0.08;
    updatePosition();
  };
  
  updatePosition();
  watchFullscreen();
})();
